import { Routes, Route } from "react-router-dom";
import NotFound from "./pages/NotFound";
import Home from "./pages/Home";
import "bootstrap/dist/css/bootstrap.min.css";
import "bootstrap/dist/js/bootstrap.min.js";
import Education from "./pages/Education";
import Login from "./pages/Login";

import { useDispatch, useSelector } from "react-redux";
import CourseCate from "./pages/CourseCate";
import Course from "./pages/Course";
import EditCourse from "./pages/EditCourse";
import Schedule from "./pages/Schedule";
import SingleCourse from "./pages/SingleCourse";
import BillPage from "./pages/BillPage";
import Classes from "./pages/Classes";
function App() {
  if (!localStorage.getItem('user')) {
    return <Login />
  }
  return (
    <div className="App">
      <Routes>
        <Route path="/" element={<Login />} />
        <Route path="/education" element={<Education />} />
        <Route path="/schedule" element={<Schedule />} />
        <Route path="/bills" element={<BillPage />} />
        <Route path="/classes" element={<Classes />} />

        <Route path="/education/:id" element={<CourseCate />} />
        <Route path="/editCourse/:id" element={<EditCourse />} />
        <Route path="/cate/:id" element={<Course />} />
        <Route path="/course/:id" element={<SingleCourse />} />
        <Route path="*" element={<NotFound />} />
      </Routes>
    </div>
  );
}

export default App;
