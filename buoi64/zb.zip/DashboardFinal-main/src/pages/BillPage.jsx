import React, { useEffect, useState } from "react";
import Sidebar from "../component/Sidebar";
import Person from "../component/Person";
import Button from "react-bootstrap/Button";
import Modal from "react-bootstrap/Modal";
import { Notyf } from "notyf";
import "notyf/notyf.min.css";
import axios from "axios";
function BillPage() {
  const url = "http://127.0.0.1:8000/api/";
  const [bills, setBill] = useState([]);
  const [show, setShow] = useState(false);
  const [show1, setShow1] = useState(false);

  const handleClose = () => setShow(false);
  const handleShow = () => setShow(true);
  const handleClose1 = () => setShow1(false);
  const handleShow1 = () => setShow1(true);
  const [courseList, setList] = useState([]);
  const [teacherList, setTeacherList] = useState([]);
  const [idCourse, setIdCourse] = useState(0);
  const [idTeacher, setIdTeacher] = useState(0);
  const [name, setName] = useState("");
  const [schedule, setSchedule] = useState("");
  const [username, setUserName] = useState("");
  const [useremail, setUserEmail] = useState("");
  const [userphone, setUserPhone] = useState("");
  const [schedulearr, setScheduleArr] = useState([]);
  const [idUsPr, setidUsPr] = useState(0);
  const [idBill, setIdBill] = useState(0);
  const [usDuration, setusDuration] = useState(0);
  const submitAddStudent = () => {
    if (idUsPr == 0) {
      notyf.open({
        type: "error",
        icon: "x",
        message: "Chưa chọn lớp học",
      });
    } else if (usDuration == 0) {
      notyf.open({
        type: "error",
        icon: "x",
        message: "Chưa nhập thời lượng học",
      });
    } else if (idBill == 0) {
      notyf.open({
        type: "error",
        icon: "x",
        message: "Chưa có mã hoá đơn",
      });
    } else {
      axios
        .post(url + "addStudent", {
          idProccess: idUsPr,
          username: username,
          email: useremail,
          phone: userphone,
          duration: usDuration,
          idBill: idBill,
        })
        .then(function (res) {
          if (res.data.check == true) {
            notyf.open({
              type: "success",
              message: "Đã sắp lớp thành công",
            });
            window.location.reload();
          } else if (res.data.check == false) {
            if (res.data.msg.idProccess) {
              notyf.open({
                type: "error",
                message: res.data.msg.idProccess,
              });
            } else if (res.data.msg.username) {
              notyf.open({
                type: "error",
                message: res.data.msg.username,
              });
            } else if (res.data.msg.email) {
              notyf.open({
                type: "error",
                message: res.data.msg.email,
              });
            } else if (res.data.msg.phone) {
              notyf.open({
                type: "error",
                message: res.data.msg.phone,
              });
            } else if (res.data.msg.duration) {
              notyf.open({
                type: "error",
                message: res.data.msg.duration,
              });
            } else if (res.data.msg.idBill) {
              notyf.open({
                type: "error",
                message: res.data.msg.idBill,
              });
            }
          }
        });
    }
  };
  const notyf = new Notyf({
    duration: 1000,
    position: {
      x: "right",
      y: "top",
    },
    types: [
      {
        type: "success",
        background: "#11b1f0",
        icon: true,
      },
      {
        type: "warning",
        background: "orange",
        icon: true,
      },
      {
        type: "error",
        background: "red",
        icon: true,
      },
    ],
  });
  const setClassFunc = (name, phone, mail, id) => {
    setUserName(name);
    setUserEmail(mail);
    setUserPhone(phone);
    setShow1(true);
    setIdBill(id);
  };
  const submitAddSchedule = () => {
    if (name == "") {
      notyf.open({
        type: "error",
        icon: "x",
        message: "Thiếu tên lớp học",
      });
    } else if (schedule == "") {
      notyf.open({
        type: "error",
        message: "Thiếu lịch của lớp học",
        icon: "x",
      });
    } else if (idCourse == 0 || idTeacher == 0) {
      notyf.open({
        type: "error",
        message: "Vui lòng chọn khoá học và giảng viên",
        icon: "x",
      });
    } else {
      axios
        .post(url + "class", {
          name: name,
          schedule: schedule,
          idCourse: idCourse,
          idTeacher: idTeacher,
        })
        .then(function (res) {
          if (res.data.check == true) {
            notyf.open({
              type: "success",
              message: "Thêm thành công",
            });
            window.location.reload();
          } else if (res.data.check == false) {
            if (res.data.msg.name) {
              notyf.open({
                type: "error",
                message: res.data.msg.name,
              });
            } else if (res.data.msg.schedule) {
              notyf.open({
                type: "error",
                message: res.data.msg.schedule,
              });
            } else if (res.data.msg.idCourse) {
              notyf.open({
                type: "error",
                message: res.data.msg.idCourse,
              });
            } else if (res.data.msg.idTeacher) {
              notyf.open({
                type: "error",
                message: res.data.msg.idTeacher,
              });
            }
          }
        })
        .catch(function (error) {
          console.log(error);
        });
    }
  };
  useEffect(() => {
    fetch(url + "bills")
      .then((res) => res.json())
      .then((res) => {
        setBill(res);
      });
    fetch(url + "class")
      .then((res) => res.json())
      .then((res) => {
        setScheduleArr(res);
      });
    fetch(url + "getCourse")
      .then((res) => res.json())
      .then((res) => {
        setList(res);
      });
    console.log(teacherList);
    fetch(url + "getTeacher")
      .then((res) => res.json())
      .then((res) => {
        setTeacherList(res);
      });
  }, []);

  return (
    <>
      <Sidebar />
      <div className="main_content dashboard_part">
        <div className="container-fluid g-0">
          <div className="row">
            <div className="col-lg-12 p-0 ">
              <div className="header_iner d-flex justify-content-between align-items-center">
                <div className="sidebar_icon d-lg-none">
                  <i className="ti-menu" />
                </div>
                <div className="serach_field-area">
                  <button
                    className="btn btn-warning"
                    onClick={(e) => handleShow()}
                  >
                    Thêm lịch học
                  </button>
                </div>
                <Person />
              </div>
            </div>
            {/* ==============================================
             */}
            <Modal show={show} onHide={handleClose}>
              <Modal.Header closeButton>
                <Modal.Title>Modal khoá học</Modal.Title>
              </Modal.Header>
              <Modal.Body>
                <input
                  type="text"
                  className="form-control mb-2"
                  placeholder="Tên khoá học"
                  onChange={(e) => setName(e.target.value)}
                />
                <input
                  type="text"
                  className="form-control mb-2"
                  placeholder="Lịch dạy"
                  onChange={(e) => setSchedule(e.target.value)}
                />
                <select
                  name=""
                  id=""
                  defaultValue={idCourse}
                  className="form-control mb-2  "
                  onChange={(e) => setIdCourse(e.target.value)}
                >
                  <option value="0" disabled>
                    Chọn khoá học
                  </option>
                  {courseList.length > 0 &&
                    courseList.map((item, index) => (
                      <option key={index} value={item.id}>
                        {item.name}
                      </option>
                    ))}
                </select>
                <select
                  name=""
                  id=""
                  defaultValue={idTeacher}
                  className="form-control mb-2"
                  onChange={(e) => setIdTeacher(e.target.value)}
                >
                  <option value="0" disabled>
                    Chọn giáo viên
                  </option>
                  {teacherList.length > 0 &&
                    teacherList.map((item, index) => (
                      <option key={index} value={item.id}>
                        {item.name}
                      </option>
                    ))}
                </select>
              </Modal.Body>
              <Modal.Footer>
                <Button variant="secondary" onClick={handleClose}>
                  Close
                </Button>
                <Button variant="primary" onClick={(e) => submitAddSchedule()}>
                  Thêm
                </Button>
              </Modal.Footer>
            </Modal>
            {/* =========================================================== */}
            <Modal show={show1} onHide={handleClose1}>
              <Modal.Header closeButton>
                <Modal.Title>Thêm học viên</Modal.Title>
              </Modal.Header>
              <Modal.Body>
                <input
                  type="text"
                  className="form-control mb-2"
                  readOnly
                  value={username}
                />
                <input
                  type="text"
                  className="form-control mb-2"
                  readOnly
                  value={useremail}
                />
                <input
                  type="text"
                  className="form-control mb-2"
                  readOnly
                  value={userphone}
                />
                <label className="mb-1">Thời lượng học</label>
                <input
                  type="number"
                  onChange={(e) => setusDuration(e.target.value)}
                  value={usDuration}
                  className="form-control"
                />
                {schedulearr.length > 0 &&
                  schedulearr.map((item, index) => (
                    <>
                      {/* <label key={index}>
                        <input type="checkbox" name="class" id="" />
                        <h4 style={{ fontSize: "17px" }}>Giảng viên : </h4>
                        <h4 style={{ fontSize: "17px" }}>Lịch giảng : </h4>
                        <h4 style={{ fontSize: "17px" }}>Tên khoá học : </h4>
                      </label> */}
                      <div className="form-check">
                        <input
                          className="form-check-input"
                          type="radio"
                          name="class"
                          id={`flexRadioDefault` + index}
                          value={item.id}
                          onClick={(e) => setidUsPr(e.target.value)}
                        />
                        <label
                          className="form-check-label"
                          htmlFor={`flexRadioDefault` + index}
                        >
                          <span>Tên giảng viên : {item.username} </span>
                          <br />
                          <span>Khoá học : {item.coursename}</span>
                          <br />
                          <span>Lịch giảng : {item.schedules}</span>
                          <br />
                        </label>
                      </div>
                    </>
                  ))}
              </Modal.Body>
              <Modal.Footer>
                <Button variant="secondary" onClick={handleClose1}>
                  Close
                </Button>
                <Button variant="primary" onClick={(e) => submitAddStudent()}>
                  Save
                </Button>
              </Modal.Footer>
            </Modal>
            {/* ============================================== */}
            <div className="mt-3">
              <div className="container">
                <div className="table-responsive">
                  <table className="table table-primary">
                    <thead>
                      <tr>
                        <th scope="col">#</th>
                        <th scope="col">Thông tin học viên</th>
                        <th scope="col">Thông tin khoá học</th>
                        <th scope="col">Trạng thái</th>
                        <th scope="col">Ngày đăng ký</th>
                      </tr>
                    </thead>
                    <tbody>
                      {bills.length == 0 && (
                        <tr>
                          <td colspan="4">Chưa có hoá đơn</td>
                        </tr>
                      )}
                      {bills.length > 0 &&
                        bills.map((item, index) => (
                          <tr className="">
                            <td scope="row">{++index}</td>
                            <td>
                              <span>Tên : {item.name}</span>
                              <br />
                              <span>Số điện thoại : {item.phone}</span>
                              <br />
                              <span>Email : {item.email}</span>
                              <br />
                              {item.status == 0 && (
                                <button
                                  className="btn-sm btn-success"
                                  onClick={(e) =>
                                    setClassFunc(
                                      item.name,
                                      item.phone,
                                      item.email,
                                      item.id
                                    )
                                  }
                                >
                                  Thêm vào lớp
                                </button>
                              )}
                            </td>
                            <td>
                              <span>Tên khoá học : {item.coursename}</span>
                              <br />
                              <span>
                                Lịch đăng ký :{" "}
                                {JSON.parse(item.schedule)[0].schedule}
                              </span>
                              <br />
                              <span>Giáo viên : {item.teacher}</span>
                              <br />
                              <span>Thời lượng : {item.duration}</span>
                            </td>
                            <td>
                              {item.status == 0 && <b>Chưa xếp lớp</b>}
                              {item.status == 1 && <b>Đã xếp lớp</b>}
                            </td>

                            <td>{item.created_at}</td>
                          </tr>
                        ))}
                    </tbody>
                  </table>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </>
  );
}

export default BillPage;
