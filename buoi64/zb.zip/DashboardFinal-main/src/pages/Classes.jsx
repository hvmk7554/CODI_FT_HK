import React, { useEffect, useState } from "react";
import { useParams } from "react-router-dom";
import Sidebar from "../component/Sidebar";
import Button from "react-bootstrap/Button";
import Modal from "react-bootstrap/Modal";
import "notyf/notyf.min.css";
import { Notyf } from "notyf";
import Swal from "sweetalert2";
import axios from "axios";
import Person from "../component/Person";

function Classes() {
  const [classes, setClasses] = useState([]);
  const url = "http://127.0.0.1:8000/api/";
  const [schedules, setSchedule] = useState("");
  const [idProcess, setIdPoccess] = useState(0);
  const [className, setClassName] = useState("");
  // ===============================
  const [show, setShow] = useState(false);
  const notyfB = new Notyf({
    duration: 1000,
    position: {
      x: "right",
      y: "top",
    },
    types: [
      {
        type: "warning",
        background: "orange",
        icon: {
          className: "material-icons",
          tagName: "i",
          text: "warning",
        },
      },
      {
        type: "error",
        background: "indianred",
        duration: 2000,
        dismissible: true,
      },
      {
        type: "success",
        background: "#03dffc",
        duration: 2000,
        dismissible: true,
      },
    ],
  });
  const handleClose = () => setShow(false);
  const handleShow = () => setShow(true);
  const submitUpdateSchedule = () => {
    if (idProcess == 0) {
      notyfB.open({
        type: "error",
        message: "Chưa có mã lớp",
      });
    } else if (schedules == "") {
      notyfB.open({
        type: "error",
        message: "Chưa có lịch dạy",
      });
    } else {
      axios
        .post(url + "updateClassChedule", {
          id: idProcess,
          schedules: schedules,
        })
        .then((res) => {
          if (res.data.check == true) {
            notyfB.open({
              type: "success",
              message: "Đã thay đổi lịch dạy",
            });
            setClasses(res.data.result);
            setSchedule("");
            setIdPoccess(0);
            setClassName("");
            handleClose();
          } else if (res.data.check == false) {
            if (res.data.msg.id) {
              notyfB.open({
                type: "error",
                message: res.data.msg.id,
              });
            } else if (res.data.msg.schedules) {
              notyfB.open({
                type: "error",
                message: res.data.msg.schedules,
              });
            }
          }
        });
    }
  };
  useEffect(() => {
    fetch(url + "runningClass")
      .then((res) => res.json())
      .then((res) => {
        setClasses(res);
      });
  }, []);
  const setEditClass = (id, schedule, classname) => {
    setIdPoccess(id);
    setSchedule(schedule);
    setClassName(classname);
    handleShow();
  };
  return (
    <>
      <Sidebar />
      <div className="main_content dashboard_part">
        <div className="container-fluid g-0">
          <div className="row">
            <div className="col-lg-12 p-0 ">
              <div className="header_iner d-flex justify-content-between align-items-center">
                <div className="sidebar_icon d-lg-none">
                  <i className="ti-menu" />
                </div>
                <div className="serach_field-area"></div>
                <Person />
              </div>
            </div>
          </div>
          <Modal show={show} onHide={handleClose}>
            <Modal.Header closeButton>
              <Modal.Title>Sửa lịch học</Modal.Title>
            </Modal.Header>
            <Modal.Body>
              <input
                type="text"
                className="form-control mb-2"
                readOnly
                value={className}
              />
              <input
                type="text"
                value={schedules}
                onChange={(e) => setSchedule(e.target.value)}
                className="form-control"
              />
            </Modal.Body>
            <Modal.Footer>
              <Button variant="secondary" onClick={handleClose}>
                Đóng
              </Button>
              <Button variant="primary" onClick={(e) => submitUpdateSchedule()}>
                Lưu
              </Button>
            </Modal.Footer>
          </Modal>
          <div className="row">
            <div className="container">
              <div class="table-responsive">
                <table class="table table-primary">
                  <thead>
                    <tr>
                      <th scope="col">#</th>
                      <th scope="col">Tên lơp học</th>
                      <th scope="col">Thông tin khoá học</th>
                      <th scope="col">Số lượng học viên</th>
                    </tr>
                  </thead>
                  <tbody>
                    {classes.length > 0 &&
                      classes.map((item, index) => (
                        <tr class="">
                          <td scope="row">{++index}</td>
                          <td>{item.className}</td>
                          <td>
                            <p style={{ fontSize: "18px", color: "black" }}>
                              Tên khoá học : {item.courseName}
                            </p>
                            <p style={{ fontSize: "18px", color: "black" }}>
                              Lịch học : {item.schedules}
                            </p>
                            <p style={{ fontSize: "18px", color: "black" }}>
                              Giảng viên : {item.teacher}
                            </p>
                            <p style={{ fontSize: "18px", color: "black" }}>
                              Số lượng đã buổi học : {item.pass}
                            </p>
                            <button
                              className="btn-sm btn-warning"
                              onClick={(e) =>
                                setEditClass(
                                  item.id,
                                  item.schedules,
                                  item.className
                                )
                              }
                            >
                              Sửa lịch
                            </button>
                          </td>
                          <td>{item.studentscount}</td>
                        </tr>
                      ))}
                  </tbody>
                </table>
              </div>
            </div>
          </div>
        </div>
      </div>
    </>
  );
}

export default Classes;
