import React, { useEffect, useState } from "react";
import { useParams } from "react-router-dom";
import Sidebar from "../component/Sidebar";
import Button from "react-bootstrap/Button";
import Modal from "react-bootstrap/Modal";
import "notyf/notyf.min.css";
import { Notyf } from "notyf";
import Swal from "sweetalert2";
import axios from "axios";
import Person from "../component/Person";

function Schedule() {
  const handleClose = () => setShow(false);
  const [show, setShow] = useState(false);
  const handleShow = () => setShow(true);
  const [courses, setCourses] = useState([]);
  const [teacher, setTeacher] = useState([]);
  const [classSchedules, setClassSch] = useState([]);
  const [schedules, setSchedule] = useState([{ schedule: "" }]);
  const [idCourse, setIdCourse] = useState(0);
  const [idTeacher, setIdTeacher] = useState(0);
  const url = "http://localhost:8000/api/";
  const notyfR = new Notyf({
    position: {
      x: "right",
      y: "top",
    },
    types: [
      {
        type: "info",
        background: "blue",
        icon: false,
      },
    ],
  });
  const addSchedule = () => {
    setSchedule((schedules) => [...schedules, { schedule: "" }]);
  };
  const deleteSchedule = (id) => {
    Swal.fire({
      icon: "question",
      text: "Xoá lịch giảng dạy?",
      showDenyButton: true,
      showCancelButton: false,
      confirmButtonText: "Đúng",
      denyButtonText: `Không`,
    }).then((result) => {
      /* Read more about isConfirmed, isDenied below */
      if (result.isConfirmed) {
        fetch(url + "deleteSchedule/" + id)
          .then((res) => res.json())
          .then((res) => {
            if (res.check == true) {
              notyfR.open({
                type: "success",
                message: "Đã xoá thành công",
              });
              setClassSch(res.result);
            } else if (res.check == false) {
              if (res.msg) {
                notyfR.open({
                  type: "error",
                  message: res.msg,
                });
              }
            }
          });
      } else if (result.isDenied) {
      }
    });
  };
  const setAdd = () => {
    handleShow();
  };
  const updateSchedule = (index, value) => {
    var sche = [...schedules];
    sche[index].schedule = value;
    setSchedule(sche);
  };
  const submitSchedule = () => {
    if (idTeacher == 0) {
      notyfR.open({
        type: "info",
        message: "Chưa chọn giáo viên",
      });
    } else if (idCourse == 0) {
      notyfR.open({
        type: "info",
        message: "Chưa chọn khoá học",
      });
    } else if (schedules.length == 0 || schedules[0].schedule == "") {
      notyfR.open({
        type: "info",
        message: "Thiếu lịch học",
      });
    } else {
      axios
        .post(url + "schedule", {
          idTeacher: idTeacher,
          idcourse: idCourse,
          schedule: JSON.stringify(schedules),
        })
        .then(function (res) {
          if (res.data.check == true) {
            notyfR.open({
              type: "success",
              message: "Đăng ký lịch dạy thành công",
            });
            setClassSch(res.data.result);
            setIdCourse(0);
            setIdTeacher(0);
            handleClose();
            setSchedule([]);
          } else if (res.data.check == false) {
            if (res.data.msg.idTeacher) {
              notyfR.open({
                type: "error",
                message: res.data.msg.idTeacher,
              });
            } else if (res.data.msg.idcourse) {
              notyfR.open({
                type: "error",
                message: res.data.msg.idcourse,
              });
            } else if (res.data.msg.schedule) {
              notyfR.open({
                type: "error",
                message: res.data.msg.schedule,
              });
            }
          }
        })
        .catch(function (error) {
          console.log(error);
        });
    }
  };

  useEffect(() => {
    fetch(url + "getTeacher")
      .then((res) => res.json())
      .then((res) => {
        setTeacher(res);
      });
    fetch(url + "getActiveCourses")
      .then((res) => res.json())
      .then((res) => {
        setCourses(res);
      });
    fetch(url + "schedule")
      .then((res) => res.json())
      .then((res) => {
        setClassSch(res);
      });
  }, []);
  return (
    <>
      <Sidebar />
      <Modal show={show} onHide={handleClose}>
        <Modal.Header closeButton>
          <Modal.Title>Thêm lịch học</Modal.Title>
        </Modal.Header>
        <Modal.Body>
          <select
            name=""
            defaultValue={0}
            onChange={(e) => setIdTeacher(e.target.value)}
            className="form-control mb-3"
            id=""
          >
            <option value="0" disabled selected>
              Chọn giáo viên
            </option>
            {teacher.length > 0 &&
              teacher.map((item, index) => (
                <option key={index} value={item.id}>
                  {item.name}
                </option>
              ))}
          </select>
          <select
            defaultValue={0}
            name=""
            className="form-control"
            onChange={(e) => setIdCourse(e.target.value)}
            id=""
          >
            <option value="0" disabled>
              Chọn khoá học
            </option>
            {courses.length > 0 &&
              courses.map((item, index) => (
                <option key={index} value={item.id}>
                  {item.name}
                </option>
              ))}
          </select>
          {schedules.length > 0 &&
            schedules.map((item, index) => (
              <div key={index} className="input-group mb-3 mt-2">
                <input
                  type="text"
                  className="form-control"
                  placeholder="Lịch giảng dạy"
                  onChange={(e) => updateSchedule(index, e.target.value)}
                />
                <button
                  className="btn btn-outline-secondary"
                  onClick={(e) => deleteSchedule(index)}
                  type="button"
                >
                  Xoá
                </button>
              </div>
            ))}

          <button
            className="btn btn-danger mt-2"
            onClick={(e) => addSchedule()}
          >
            Thêm lịch giảng
          </button>
        </Modal.Body>
        <Modal.Footer>
          <Button variant="primary" onClick={(e) => submitSchedule()}>
            Lưu
          </Button>
        </Modal.Footer>
      </Modal>
      <div className="main_content dashboard_part">
        <div className="container-fluid g-0">
          <div className="row">
            <div className="col-lg-12 p-0 ">
              <div className="header_iner d-flex justify-content-between align-items-center">
                <div className="sidebar_icon d-lg-none">
                  <i className="ti-menu" />
                </div>
                <div className="serach_field-area">
                  <button className="btn btn-primary" onClick={(e) => setAdd()}>
                    Thêm
                  </button>
                </div>
                <Person />
              </div>
            </div>
          </div>
          <div className="container">
            <div className="row ">
              <div className="p-3  ">
                {classSchedules.length > 0 && (
                  <div className="table-responsive">
                    <table className="table table-primary">
                      <thead>
                        <tr>
                          <th scope="col">#</th>
                          <th scope="col">Tên khoá học</th>
                          <th scope="col">Giảng viên</th>
                          <th scope="col">Lịch dạy</th>
                          <th scope="col">Xoá</th>
                        </tr>
                      </thead>
                      <tbody>
                        {classSchedules.map((item, index) => (
                          <tr key={index} className="">
                            <td scope="row">{++index}</td>
                            <td>{item.coursename}</td>
                            <td>{item.teacher}</td>
                            <td>
                              <ul style={{ paddingLeft: "0%" }}>
                                {JSON.parse(item.schedule).map(
                                  (item1, index1) => (
                                    <li key={index1}>{item1.schedule}</li>
                                  )
                                )}
                              </ul>
                            </td>
                            <td>
                              <button
                                className="btn-sm btn-danger"
                                onClick={(e) => deleteSchedule(item.id)}
                              >
                                Xoá
                              </button>
                            </td>
                          </tr>
                        ))}
                      </tbody>
                    </table>
                  </div>
                )}
                {classSchedules.length == 0 && (
                  <div className="table-responsive">
                    <table className="table table-primary">
                      <thead>
                        <tr>
                          <th colSpan={3} scope="col">
                            Chưa có lịch giảng dạy
                          </th>
                        </tr>
                      </thead>
                    </table>
                  </div>
                )}
              </div>
            </div>
          </div>
        </div>
      </div>
    </>
  );
}

export default Schedule;
