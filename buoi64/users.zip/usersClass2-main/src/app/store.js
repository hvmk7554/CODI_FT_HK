import { configureStore } from '@reduxjs/toolkit';
import EduReducer from "./eduSlice";
export const store = configureStore({
    reducer: {
        educations: EduReducer,
    },
});