import React, { useEffect, useState } from "react";
import { useParams } from "react-router-dom";
import Header from "../components/Header";
import Button from "react-bootstrap/Button";
import Modal from "react-bootstrap/Modal";
import { Notyf } from "notyf";
import "notyf/notyf.min.css"; // for React, Vue and Svelte
import DetailSLide from "../components/DetailSLide";
import axios from "axios";
function Detail() {
  const url = "http://localhost:8000/api/";
  const urlimg = "http://localhost:8000/images/";
  const { id } = useParams();
  const [course, setCourse] = useState({});
  const [duration, setDuration] = useState([]);
  const [schedules, setSchedule] = useState([]);
  const [modules, setModule] = useState([]);
  const [idDuration, setIdDuration] = useState(0);
  const [idSchedule, setidSchedule] = useState(0);
  const [courseInfo, setCourseInfo] = useState([]);
  const notyf = new Notyf({
    duration: 1000,
    position: {
      x: "right",
      y: "top",
    },
    types: [
      {
        type: "warning",
        background: "orange",
        icon: {
          className: "material-icons",
          tagName: "i",
          text: "warning",
        },
      },
      {
        type: "error",
        background: "indianred",
        duration: 2000,
        dismissible: true,
      },
    ],
  });
  // ==================================
  const [show, setShow] = useState(false);
  const [name, setName] = useState("");
  const [email, setEmail] = useState("");
  const [phone, setPhone] = useState("");

  const handleClose = () => setShow(false);
  const handleShow = () => setShow(true);
  const setBuyCourse = () => {
    if (idDuration == 0) {
      notyf.open({
        type: "error",
        message: "Vui lòng chọn thời lượng học",
      });
    } else if (idSchedule == 0) {
      notyf.open({
        type: "error",
        message: "Vui lòng chọn lịch học",
      });
    } else {
      handleShow();
    }
  };
  const validatePhone = (phone) => {
    if (phone.match(patternphone)) {
      setPhone(phone);
    }
  };
  const pattern = /^\S+@\S+\.\S+$/;
  const patternphone = /(0[3|5|7|8|9])+([0-9]{8})\b/g;
  const validateEmail = (email) => {
    if (email.match(pattern)) {
      setEmail(email);
    } else {
      console.log("unmatch");
    }
  };
  const SubmitBillCourse = () => {
    if (name == "" || email == "" || phone == "") {
      notyf.open({
        type: "error",
        message: "Vui lòng nhập đúng thông tin yêu cầu",
      });
    } else {
      axios
        .post(url + "bill", {
          name: name,
          phone: phone,
          email: email,
          idSchedule: idSchedule,
          idDuration: idDuration,
        })
        .then(function (res) {
          if (res.data.check == true) {
            notyf.open({
              type: "success",
              message: "Đăng ký khoá học thành công",
            });
            window.location.reload();
          }
        })
        .catch(function (error) {
          console.log(error);
        });
    }
  };
  const setIdDuration1 = (id) => {
    var duration1 = duration;
    var obj = [];
    duration1.forEach((el) => {
      if (el.id == id) {
        var durationcourse = el.duration;
        var pricecourse = el.price;
        var obj1 = {};
        obj1.durationBook = durationcourse;
        obj1.price = pricecourse;
        obj.push(obj1);
      }
    });
    setCourseInfo(obj);
    setIdDuration(id);
  };
  const setidSchedule1 = (id) => {
    var schedule1 = schedules;
    var obj = [...courseInfo];
    schedule1.forEach((el) => {
      if (el.id == id) {
        obj[0].schedule = JSON.parse(el.schedule)[0].schedule;
      }
    });
    setCourseInfo(obj);
    console.log(courseInfo);
    setidSchedule(id);
  };
  useEffect(() => {
    fetch(url + "single/" + id)
      .then((res) => res.json())
      .then((res) => {
        setCourse(res.course[0]);
        setDuration(res.duration);
        setSchedule(res.schedules);
        let module = JSON.parse(res.course[0].detail);
        setModule(module);
      });
  }, [id]);
  return (
    <>
      <Modal show={show} onHide={handleClose}>
        <Modal.Header closeButton>
          <Modal.Title>Đăng ký khoá học</Modal.Title>
        </Modal.Header>
        <Modal.Body>
          <input
            type="text"
            placeholder="Họ và tên"
            className={
              name == ""
                ? "form-control mb-3 border-danger"
                : "form-control mb-3 border-success"
            }
            onChange={(e) => setName(e.target.value)}
          />
          <input
            type="text"
            placeholder="Số diện thoại"
            className={
              phone == ""
                ? "form-control mb-3 border-danger"
                : "form-control mb-3 border-success"
            }
            onChange={(e) => validatePhone(e.target.value)}
          />
          <input
            type="text"
            placeholder="Email"
            className={
              email == ""
                ? "form-control mb-3 border-danger"
                : "form-control mb-3 border-success"
            }
            onChange={(e) => validateEmail(e.target.value)}
          />
          {courseInfo.length > 0 && (
            <>
              {" "}
              <p className="mb-2">
                Thời lượng học : {courseInfo[0].durationBook}
              </p>
              <p className="mb-2">Lịch học : {courseInfo[0].schedule}</p>
              <p className="mb-2">Giá tiền : {courseInfo[0].price}</p>
            </>
          )}
        </Modal.Body>
        <Modal.Footer>
          <Button variant="secondary" onClick={handleClose}>
            Close
          </Button>
          <Button variant="primary" onClick={(e) => SubmitBillCourse()}>
            Mua
          </Button>
        </Modal.Footer>
      </Modal>
      <Header />
      <DetailSLide />
      <div className="container py-5">
        <div className="row pt-5">
          <div className="col-lg-8">
            <div className="d-flex flex-column text-left mb-3">
              <p className="section-title pr-5">
                <span className="pr-2">Blog Detail Page</span>
              </p>
              <h1 className="mb-3">{course.name}</h1>
              <div className="d-flex">
                <p className="mr-3">
                  <i className="fa fa-user text-primary" /> Course
                </p>
                <p className="mr-3">
                  <i className="fa fa-folder text-primary" />
                  Detail
                </p>
              </div>
            </div>
            <div className="mb-5">
              <img
                className="img-fluid rounded w-100 mb-4"
                src={urlimg + course.image}
                alt="Image"
              />
              <p>{course.summary}</p>
              <div className="accordion accordion-flush" id="accordantModule">
                {modules.length > 0 &&
                  modules.map((item, index) => (
                    <div key={index} className="accordion-item">
                      <h2
                        className="accordion-header"
                        id={`flush-heading` + index}
                      >
                        <button
                          className="accordion-button collapsed"
                          type="button"
                          data-bs-toggle="collapse"
                          data-bs-target={`#flush-collapse` + index}
                          aria-expanded="false"
                          aria-controls={`flush-collapse1` + index}
                        >
                          {item.name}
                        </button>
                      </h2>
                      <div
                        id={`flush-collapse` + index}
                        className="accordion-collapse collapse"
                        aria-labelledby={`flush-heading` + index}
                        data-bs-parent="#accordantModule"
                      >
                        <div
                          className="accordion-body"
                          dangerouslySetInnerHTML={{ __html: item.content }}
                        />
                      </div>
                    </div>
                  ))}
              </div>
            </div>
            {/* Related Post */}
            {/* Comment Form */}
          </div>
          <div className="col-lg-4 mt-5 mt-lg-0">
            {/* Author Bio */}
            <div
              className="d-flex flex-column text-center rounded"
              style={{ height: "100px", width: "100px", margin: "0px auto" }}
            >
              <img
                src={"https://marathon.edu.vn/images/logo-3.png"}
                className="img-fluid "
                style={{ width: 100 }}
              />

              {/* Image */}
            </div>
            {/* Search Form */}

            {/* Category List */}
            <div className="mb-5">
              <h2 className="mb-4">Thời lượng học</h2>
              {duration.length > 0 && (
                <select
                  name=""
                  id=""
                  defaultValue={0}
                  className="form-control mt-3"
                  onChange={(e) => setIdDuration1(e.target.value)}
                >
                  <option value="0" disabled>
                    Chọn thời lượng học
                  </option>
                  {duration.map((item, index) => (
                    <option key={index} value={item.id}>
                      {item.duration}h -{" "}
                      {Intl.NumberFormat("de-DE", {
                        style: "currency",
                        currency: "VND",
                      }).format(item.price)}
                    </option>
                  ))}
                </select>
              )}
            </div>
            <div className="mb-5">
              <h2 className="mb-4">Lịch học</h2>
              {schedules.length > 0 && (
                <select
                  name=""
                  id=""
                  defaultValue={0}
                  className="form-control mt-3"
                  onChange={(e) => setidSchedule1(e.target.value)}
                >
                  <option value="0" disabled>
                    Chọn lịch học
                  </option>
                  {schedules.map((item, index) => (
                    <option key={index} value={item.id}>
                      {JSON.parse(item.schedule)[0].schedule}
                    </option>
                  ))}
                </select>
              )}
            </div>
            {/* Single Image */}
            <div className="mb-5  text-center">
              <button
                className="btn btn-primary"
                onClick={(e) => setBuyCourse()}
              >
                Đăng ký
              </button>
            </div>
            {/* Recent Post */}
            {/* Single Image */}

            {/* Tag Cloud */}
            {/* Single Image */}
          </div>
        </div>
      </div>
    </>
  );
}

export default Detail;
