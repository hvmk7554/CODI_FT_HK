import React, { useEffect, useState } from "react";
import Header from "../components/Header";
import Slider from "../components/Slider";
import About from "../components/About";
import Facilities from "../components/Facilities";
import Contact from "../components/Contact";
import Teacher from "../components/Teacher";
import Testimonial from "../components/Testimonial";
import Blog from "../components/Blog";
import Footer from "../components/Footer";
function Home() {
  const url = "http://127.0.0.1:8000/api/";
  const url1 = "http://127.0.0.1:8000/images/";
  const [courses, setCourse] = useState([]);

  useEffect(() => {
    fetch(url + "currentCourses")
      .then((res) => res.json())
      .then((res) => {
        setCourse(res);
      });
  }, []);
  return (
    <>
      <Header />
      <Slider />
      <Facilities />
      <About />
      {/* ================= Courses ======================== */}
      <div className="container-fluid pt-5">
        <div className="container">
          <div className="text-center pb-2">
            <p className="section-title px-5"></p>
            <h1 className="mb-4">Khoá học mới nhất</h1>
          </div>
          {courses.length > 0 && (
            <div className="row">
              {courses.map((item, index) => (
                <div key={index} className="col-lg-4 mb-5">
                  <div className="card border-0 bg-light shadow-sm pb-2">
                    <img
                      className="card-img-top mb-2"
                      src={url1 + item.image}
                      alt=""
                    />
                    <div className="card-body text-center">
                      <h4 className="card-title">{item.name}</h4>
                      <p className="card-text">{item.summary}</p>
                    </div>
                    {/* <div className="card-footer bg-transparent py-4 px-5">
                      <div className="row border-bottom">
                        <div className="col-6 py-1 text-right border-right">
                          <strong>Age of Kids</strong>
                        </div>
                        <div className="col-6 py-1">3 - 6 Years</div>
                      </div>
                      <div className="row border-bottom">
                        <div className="col-6 py-1 text-right border-right">
                          <strong>Total Seats</strong>
                        </div>
                        <div className="col-6 py-1">40 Seats</div>
                      </div>
                      <div className="row border-bottom">
                        <div className="col-6 py-1 text-right border-right">
                          <strong>Class Time</strong>
                        </div>
                        <div className="col-6 py-1">08:00 - 10:00</div>
                      </div>
                      <div className="row">
                        <div className="col-6 py-1 text-right border-right">
                          <strong>Tution Fee</strong>
                        </div>
                        <div className="col-6 py-1">$290 / Month</div>
                      </div>
                    </div> */}
                    <a
                      href={`/detail/` + item.id}
                      className="btn btn-primary px-4 mx-auto mb-4"
                    >
                      Xem thêm
                    </a>
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>
      </div>
      <Contact />
      <Teacher />
      <Testimonial />
      <Blog />
      <Footer />
    </>
  );
}

export default Home;
