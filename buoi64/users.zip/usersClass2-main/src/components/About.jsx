import React from "react";

function About() {
  return (
    <>
      <div className="container-fluid py-5">
        <div className="container">
          <div className="row align-items-center">
            <div className="col-lg-5">
              <img
                className="img-fluid rounded mb-5 mb-lg-0"
                src="img/about-1.jpg"
                alt=""
              />
            </div>
            <div className="col-lg-7">
              <p className="section-title pr-5">
                <span className="pr-2">Marathon Education</span>
              </p>
              <h1 className="mb-4">
                Nền Tảng Học Trực Tuyến Hàng Đầu Việt Nam
              </h1>
              <p>
                Nền tảng học online Marathon Education cải thiện và nâng cao học
                lực của bạn với nhiều loại hình giảng dạy kết hợp với công nghệ
                thu thập và xử lý dữ liệu theo từng buổi học.
              </p>
              <div className="row pt-2 pb-4">
                <div className="col-6 col-md-4">
                  <img
                    className="img-fluid rounded"
                    src="img/about-2.jpg"
                    alt=""
                  />
                </div>
                <div className="col-6 col-md-8">
                  <ul className="list-inline m-0">
                    <li className="py-2 border-top border-bottom">
                      <i className="fa fa-check text-primary mr-3" />
                      Nền Tảng Học Tập Tương Tác Trực Tuyến
                    </li>
                    <li className="py-2 border-bottom">
                      <i className="fa fa-check text-primary mr-3" />
                      Thầy Cô Và Cộng Đồng Học Tập Dẫn Đầu
                    </li>
                    <li className="py-2 border-bottom">
                      <i className="fa fa-check text-primary mr-3" />
                      Khoá Học Đa Dạng Theo Nhu Cầu
                    </li>
                  </ul>
                </div>
              </div>
              <a href="#" className="btn btn-primary mt-2 py-2 px-4">
                Learn More
              </a>
            </div>
          </div>
        </div>
      </div>
    </>
  );
}

export default About;
