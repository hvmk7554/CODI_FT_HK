import React from "react";

function Facility(props) {
  return (
    <>
      <div class="col-lg-4 col-md-6 pb-1">
        <div
          class="d-flex bg-light shadow-sm border-top rounded mb-4"
          style={{ padding: "30px" }}
        >
          <i class="flaticon-050-fence h1 font-weight-normal text-primary mb-3"></i>
          <div class="pl-4">
            <h4>{props.title}</h4>
            <p class="m-0">{props.content}</p>
          </div>
        </div>
      </div>
    </>
  );
}

export default Facility;
