import React from "react";
import Facility from "./Facility";

function Facilities() {
  return (
    <>
      <div className="container-fluid pt-5">
        <div className="container pb-3">
          <div className="row">
            <Facility
              title="Play Ground"
              content="Môi trường sinh hoạt lành mạnh"
            />
            <Facility
              title="Student funny"
              content="Học tập sáng tạo vui tươi"
            />
            <Facility
              title="Music and Dance"
              content="Giúp bé tự tin thể hiện tài năng"
            />
            <Facility
              title="Arts and Crafts"
              content="Môi trường tự do sáng tạo"
            />
            <Facility
              title="Healthy food"
              content="Thực phẩm đẩy đủ dinh dưỡng "
            />
            <Facility
              title="Educational Tour"
              content="Một ngày làm học sinh tại trường"
            />
          </div>
        </div>
      </div>
    </>
  );
}

export default Facilities;
