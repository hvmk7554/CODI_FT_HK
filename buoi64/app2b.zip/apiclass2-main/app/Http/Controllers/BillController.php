<?php

namespace App\Http\Controllers;

use App\Models\BillM;
use Illuminate\Http\Request;

use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Validator;
use Illuminate\Support\Facades\Mail;
use App\Mail\BillMail;
class BillController extends Controller
{
    /**
     * Display a listing of the resource.
     */
    public function index()
    {
        $result= DB::Table('bill_tbl')
        ->join('class_schedule','bill_tbl.idSchedule','=','class_schedule.id')
        ->join('course_duration','bill_tbl.idDuration','course_duration.id')
        ->join('courses','course_duration.idCourse','=','courses.id')
        ->join('users','class_schedule.idTeacher','=','users.id')
        ->select('bill_tbl.*','class_schedule.schedule as schedule','users.name as teacher','course_duration.duration as duration','courses.name as coursename')
        ->get();
        return response()->json($result);
    }


    /**
     * Show the form for creating a new resource.
     */
    public function create(Request $request)
    {
        $validator =  Validator::make(
            $request->all(),
            [
                'name' => 'required',
                'phone'=>'required',
                'email'=>'required|email',
                'idSchedule'=>'required|exists:class_schedule,id',
                'idDuration'=>'required|exists:course_duration,id',

            ],
            // [
            //     'duration.required' => 'Thiếu thời lượng khoá học',
            //     'duration.min' => 'Thời lượng khoá học không hợp lệ',
            //     'price.required'=>'Thiếu giá khoá học',
            //     'price.min'=>'Giá khoá học không hợp lệ',
            //     'id.required'=>'Thiếu mã khoá học',
            //     'id.exists'=>'Mã khoá học không tồn tại',
            // ],
        );
        if ($validator->fails()) {
            return response()->json(['check' => false, 'msg' => $validator->errors()]);
        }
        BillM::create(['name'=>$request->name,'email'=>$request->email,'phone'=>$request->phone,'idSchedule'=>$request->idSchedule,'idDuration'=>$request->idDuration]);
        $result =  DB::Table('class_schedule')
        ->join('courses','class_schedule.idcourse','=','courses.id')
        ->join('course_duration','courses.id','=','course_duration.idCourse')
        ->where('class_schedule.id',$request->idSchedule)
        ->where('course_duration.id',$request->idDuration)
        ->select('courses.name as name','course_duration.price as price','courses.discount as discount')
        ->first();
        $course = (object) [
                'name'=>'',
                'price'=>0,
            ];
            $course->name = $result->name;
            $course->price =$result->price * (100-$result->discount)/100;
            $mailData=[
                'name'=>$request->name,
                'course'=>$course,
            ];
            Mail::to($request->email)->cc('leodomsolar@gmail.com')->send(new BillMail($mailData));
            return  response()->json(['check'=>true]);
        }   

    /**
     * Store a newly created resource in storage.
     */
    public function store(Request $request)
    {
        //
    }

    /**
     * Display the specified resource.
     */
    public function show(BillM $billM)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     */
    public function edit(BillM $billM)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     */
    public function update(Request $request, BillM $billM)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     */
    public function destroy(BillM $billM)
    {
        //
    }
}
