<?php

namespace App\Http\Controllers;

use App\Models\EduM;
use App\Models\CateM;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Validator;
class EducationController extends Controller
{
    /**
     * Display a listing of the resource.
     */
    public function getData(){
        $result = DB::Table('edu_tbl')->paginate(4);
        return $result;
    }
    public function index()
    {
        $result = DB::Table('edu_tbl')->paginate(4);
        return response()->json($result);
    }

    /**
     * Show the form for creating a new resource.
     */
    public function activeEdu()
    {
        $result = EduM::where('status',1)->select('id','name')->get();
        return response()->json($result);
    }

    /**
     * Store a newly created resource in storage.
     */
    public function store(Request $request)
    {
        $validator = Validator::make(
            $request->all(),
            [
                'name' => 'required|unique:edu_tbl,name',
            ],
            [
                'name.required' => 'Thiếu tên loại hình giáo dục',
                'name.unique' => 'Loại hình giáo dục đã được tạo',
            ],
        );
        if ($validator->fails()) {
            return response()->json(['check' => false, 'msg' => $validator->errors()]);
        }
        EduM::create(['name' => $request->name]);
      $result = $this->getData();
        return response()->json(['check' => true, 'edu' => $result]);
    }
    /**
     * Display the specified resource.
     */
    public function editEdu(Request $request)
    {
        $validator = Validator::make(
            $request->all(),
            [
                'name' => 'required|unique:edu_tbl,name',
                'id' => 'required|exists:edu_tbl,id',
            ],
            [
                'name.required' => 'Thiếu tên loại hình giáo dục',
                'name.unique' => 'Loại hình giáo dục đã được tạo',
                'id.required' => 'Thiếu mã loại giáo dục',
                'id.exists' => 'Mã loại giáo dục không tồn tại',
            ],
        );
        if ($validator->fails()) {
            return response()->json(['check' => false, 'msg' => $validator->errors()]);
        }
        EduM::where('id', $request->id)->update(['name' => $request->name, 'updated_at' => now()]);
      $result = $this->getData();
        return response()->json(['check' => true, 'edu' => $result]);
    }
    /**
     * Display the specified resource.
     */
    public function switchEdu(Request $request)
    {
        $validator = Validator::make(
            $request->all(),
            [
                'status' => 'required|numeric|min:0|max:1',
                'id' => 'required|exists:edu_tbl,id',
            ],
            [
                'status.required' => 'Thiếu mã status hình giáo dục',
                'status.numeric' => 'Mã status không hợp lệ', 
                'status.min' => 'Mã status không hợp lệ',
                'status.max' => 'Mã status không hợp lệ',
                'id.required' => 'Thiếu mã loại giáo dục',
                'id.exists' => 'Mã loại giáo dục không tồn tại',
            ],
        );
        if ($validator->fails()) {
            return response()->json(['check' => false, 'msg' => $validator->errors()]);
        }
        EduM::where('id', $request->id)->update(['status' => $request->status, 'updated_at' => now()]);
        $result = $this->getData();
        return response()->json(['check' => true, 'edu' => $result]);
    }
    // =================================
    public function deleteEdu(Request $request)
    {
        $validator = Validator::make(
            $request->all(),
            [
                'id' => 'required|exists:edu_tbl,id',
            ],
            [
                'id.required' => 'Thiếu mã loại hình giáo dục',
                'id.exists' => 'Mã loại hình giáo dục không tồn tại',
            ],
        );
        if ($validator->fails()) {
            return response()->json(['check' => false, 'msg' => $validator->errors()]);
        }
        $check= CateM::where('idEdu',$request->id)->count('id');
        if($check!=0){
            return response()->json(['check'=>false,'msg'=>'Loại hình giáo dục có lớp']);
        }
        EduM::where('id',$request->id)->delete();
        $result = $this->getData();
        return response()->json(['check'=>true,'edu'=>$result]);
    }
    /**
     * Display the specified resource.
     */
    public function show(EduM $eduM)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     */
    public function edit(EduM $eduM)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     */
    public function update(Request $request, EduM $eduM)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     */
    public function destroy(EduM $eduM)
    {
        //
    }
}
