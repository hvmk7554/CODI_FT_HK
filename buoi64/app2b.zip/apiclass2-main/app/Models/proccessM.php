<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class proccessM extends Model
{
    protected $table='process_tbl';
    protected $fillable=['id','name','idTeacher','schedules','idCourse','pass','created_at','updated_at'];
    use HasFactory;
}
