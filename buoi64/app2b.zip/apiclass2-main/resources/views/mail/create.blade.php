<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Document</title>
</head>
<body style="width:50%;margin:0px auto;">
    <div style="line-height:40px;background-color: grey;color:white;margin-top:0%">
        <h4 style="font-family: 'Times New Roman', Times, serif;font-size:19px;text-align:center;color:white">Email thông báo tài khoản</h4>
    </div>
    <div style="padding:0px 12px;border:1px solid black">
        <h4 style="font-family: 'Times New Roman', Times, serif;font-size:17px;text-align:left;color:black">Tên tài khoản : {{$mailData['name']}}</h4>
        <h4 style="font-family: 'Times New Roman', Times, serif;font-size:17px;text-align:left;color:black">Email : {{$mailData['email']}}</h4>
        @if (isset($mailData['password']))
        <h4 style="font-family: 'Times New Roman', Times, serif;font-size:17px;text-align:left;color:black">Mật khẩu : {{$mailData['password']}}</h4>
            
        @endif
    </div>
</body>
</html>