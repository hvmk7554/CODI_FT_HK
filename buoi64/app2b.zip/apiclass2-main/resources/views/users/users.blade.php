<style>
    .pointer {
        cursor: pointer;
    }
</style>
@extends('layout.layout')
@section('main')
    <div class="modal fade" id="UserModal" tabindex="-1" aria-labelledby="UserModalLabel" aria-hidden="true">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="UserModalLabel">Modal User</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <div class="modal-body">
                    <input type="text" class="form-control mb-2" id="username" placeholder="Username">
                    <input type="text" class="form-control mb-2" id="email" placeholder="Email">
                    <label for="">Loại tài khoản</label>
                    <select name="" id="userRole" class="form-control">
                        @foreach ($roles as $item)
                            <option value="{{ $item->id }}">{{ $item->name }}</option>
                        @endforeach
                    </select>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
                    <button type="button" class="btn btn-primary" id="submitUserBtn">Save</button>
                </div>
            </div>
        </div>
    </div>

    {{-- ============================== --}}
    <div class="modal fade" id="editUserModal" tabindex="-1" aria-labelledby="editUserModalLabel" aria-hidden="true">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="editUserModalLabel">Sửa tài khoản</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <div class="modal-body">
                    <input type="text" id="editValue" class="form-control">
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
                    <button type="button" class="btn btn-primary" id="submiteditBtn">Lưu</button>
                </div>
            </div>
        </div>
    </div>
    {{-- =================== --}}
    <div class="row">
        @if (count($users) > 0)
            <div class="table-responsive">
                <table class="table table-primary">
                    <thead>
                        <tr>
                            <th scope="col">#</th>
                            <th scope="col">Username</th>
                            <th scope="col">Email</th>
                            <th scope="col">Loại tài khoản</th>
                            <th scope="col">Status</th>
                            <th scope="col">Ngày tạo</th>
                            <th scope="col">Xoá</th>
                        </tr>
                    </thead>
                    <tbody>
                        @foreach ($users as $key => $item)
                            <tr>
                                <td>{{ ++$key }}</td>
                                <td><span class="pointer editUserName"
                                        data-id='{{ $item->id }}'>{{ $item->name }}</span></td>
                                <td><span class="pointer editUserEmail"
                                        data-id='{{ $item->id }}'>{{ $item->email }}</span></td>
                                <td>
                                    <select name="" id="" class="form-control editUserRole"
                                        data-id='{{ $item->id }}'>
                                        @foreach ($roles as $item1)
                                            @if ($item1->id == $item->idRole)
                                                <option value="{{ $item1->id }}" selected>{{ $item1->name }}</option>
                                            @else
                                                <option value="{{ $item1->id }}">{{ $item1->name }}</option>
                                            @endif
                                        @endforeach
                                    </select>
                                </td>
                                <td>
                                    <select name="" id="" class="form-control editUserStatus"
                                        data-id="{{ $item->id }}">
                                        @if ($item->status == 0)
                                            <option value="0" selected>Đang khoá</option>
                                            <option value="1">Đang mở</option>
                                        @else
                                            <option value="0">Đang khoá</option>
                                            <option value="1" selected>Đang mở</option>
                                        @endif
                                    </select>
                                </td>
                                <td>
                                    {{ $item->created_at }}
                                </td>
                                <td>
                                    <button class="btn btn-danger">Xoá</button>
                                </td>
                            </tr>
                        @endforeach
                    </tbody>
                </table>
            </div>
        @endif


    </div>
    <script>
        $(document).ready(function() {
            addUser();
            editUserRole();
            editUserStatus();
            editUserEmail();editUserName()
        });
        const Toast = Swal.mixin({
            toast: true,
            position: "top-end",
            showConfirmButton: false,
            timer: 1700,
            timerProgressBar: true,
            didOpen: (toast) => {
                toast.onmouseenter = Swal.stopTimer;
                toast.onmouseleave = Swal.resumeTimer;
            }
        });
        function editUserName() {
            $('.editUserName').click(function(e) {
                e.preventDefault();
                var id = $(this).attr('data-id');
                var old =$(this).text();
                $("#editValue").val(old);
                $("#editUserModal").modal('show');
                $("#submiteditBtn").click(function(e) {
                    e.preventDefault();
                    var name = $("#editValue").val().trim();
                    if (name == '') {
                        Toast.fire({
                            icon: "error",
                            title: "Thiếu email tài khoản"
                        })
                    } else {
                        $.ajax({
                            type: "post",
                            url: "/updateUSname",
                            data: {
                                id: id,
                                name: name
                            },
                            dataType: "JSON",
                            success: function(res) {
                                if (res.check == true) {
                                    Toast.fire({
                                        icon: "success",
                                        title: "Thay đổi tên tài khoản thành công"
                                    }).then(() => {
                                        window.location.reload();
                                    })
                                }
                                if (res.msg.id) {
                                    Toast.fire({
                                        icon: "error",
                                        title: res.msg.id
                                    })
                                } else if (res.msg.name) {
                                    Toast.fire({
                                        icon: "error",
                                        title: res.msg.name
                                    })
                                }
                            }
                        });
                    }
                });
            });
        }

        function editUserEmail() {
            $('.editUserEmail').click(function(e) {
                e.preventDefault();
                var id = $(this).attr('data-id');
                var old =$(this).text();
                $("#editValue").val(old);
                $("#editUserModal").modal('show');
                $("#submiteditBtn").click(function(e) {
                    e.preventDefault();
                    var email = $("#editValue").val().trim();
                    if (email == '') {
                        Toast.fire({
                            icon: "error",
                            title: "Thiếu email tài khoản"
                        })
                    } else {
                        $.ajax({
                            type: "post",
                            url: "/updateUSemail",
                            data: {
                                id: id,
                                email: email
                            },
                            dataType: "JSON",
                            success: function(res) {
                                if (res.check == true) {
                                    Toast.fire({
                                        icon: "success",
                                        title: "Thay đổi email thành công"
                                    }).then(() => {
                                        window.location.reload();
                                    })
                                }
                                if (res.msg.id) {
                                    Toast.fire({
                                        icon: "error",
                                        title: res.msg.id
                                    })
                                } else if (res.msg.email) {
                                    Toast.fire({
                                        icon: "error",
                                        title: res.msg.email
                                    })
                                }
                            }
                        });
                    }
                });
            });
        }

        function editUserStatus() {
            $(".editUserStatus").change(function(e) {
                e.preventDefault();
                var id = $(this).attr('data-id');
                var status = $(this).val();
                Swal.fire({
                    icon: 'question',
                    text: "Muốn thay đổi trạng thái tài khoản?",
                    showDenyButton: true,
                    showCancelButton: false,
                    confirmButtonText: "Đúng",
                    denyButtonText: `Không`
                }).then((result) => {
                    /* Read more about isConfirmed, isDenied below */
                    if (result.isConfirmed) {
                        $.ajax({
                            type: "post",
                            url: "/updateUSstatus",
                            data: {
                                id: id,
                                status: status
                            },
                            dataType: "JSON",
                            success: function(res) {
                                if (res.check == true) {
                                    Toast.fire({
                                        icon: "success",
                                        title: "Thay đổi thành công"
                                    }).then(() => {
                                        window.location.reload();
                                    });
                                }
                                if (res.msg.id) {
                                    Toast.fire({
                                        icon: "error",
                                        title: res.msg.id
                                    });
                                } else if (res.msg.status) {
                                    Toast.fire({
                                        icon: "error",
                                        title: res.msg.status
                                    });
                                }
                            }
                        });
                    } else if (result.isDenied) {}
                });

            });
        }

        function editUserRole() {
            $('.editUserRole').change(function(e) {
                e.preventDefault();
                var id = $(this).attr('data-id');
                var role = $(this).val();
                Swal.fire({
                    icon: 'question',
                    text: "Muốn thay đổi loại tài khoản không ?",
                    showDenyButton: true,
                    showCancelButton: false,
                    confirmButtonText: "Đúng",
                    denyButtonText: `Không`
                }).then((result) => {
                    /* Read more about isConfirmed, isDenied below */
                    if (result.isConfirmed) {
                        $.ajax({
                            type: "post",
                            url: "/updateUSRole",
                            data: {
                                id: id,
                                role: role
                            },
                            dataType: "JSON",
                            success: function(res) {
                                if (res.check == true) {
                                    Toast.fire({
                                        icon: "success",
                                        title: "Thay đổi loại tài khoản thành công"
                                    }).then(() => {
                                        window.location.reload();
                                    });
                                }
                                if (res.msg.id) {
                                    Toast.fire({
                                        icon: "error",
                                        title: res.msg.id
                                    });
                                } else if (res.msg.role) {
                                    Toast.fire({
                                        icon: "error",
                                        title: res.msg.role
                                    });
                                }
                            }
                        });
                    } else if (result.isDenied) {}
                });

            });
        }
        // ===================================
        function addUser() {
            $("#addUserBtn").click(function(e) {
                e.preventDefault();
                $("#UserModal").modal('show');
                $('#submitUserBtn').click(function(e) {
                    e.preventDefault();
                    var name = $("#username").val().trim();
                    var email = $("#email").val().trim();
                    var idRole = $("#userRole option:selected").val();
                    if (name == '') {
                        Toast.fire({
                            icon: "error",
                            title: "Thiếu tên tài khoản"
                        });
                    } else if (email == '') {
                        Toast.fire({
                            icon: "error",
                            title: "Thiếu email tài khoản"
                        });
                    } else {
                        $.ajax({
                            type: "post",
                            url: "/user",
                            data: {
                                name: name,
                                email: email,
                                idRole: idRole,
                            },
                            dataType: "JSON",
                            success: function(res) {
                                if (res.check == true) {
                                    Toast.fire({
                                        icon: "success",
                                        title: "Đã thêm thành công"
                                    }).then(() => {
                                        window.location.reload();
                                    });
                                }
                                if (res.msg.name) {
                                    Toast.fire({
                                        icon: "error",
                                        title: res.msg.name
                                    });
                                } else if (res.msg.email) {
                                    Toast.fire({
                                        icon: "error",
                                        title: res.msg.email
                                    });
                                } else if (res.msg.idRole) {
                                    Toast.fire({
                                        icon: "error",
                                        title: res.msg.idRole
                                    });
                                }
                            }
                        });
                    }
                });
            });
        }
    </script>
@endsection
@section('menunav')
    <button class="btn btn-primary" id="addUserBtn"> Thêm</button>
@endsection
