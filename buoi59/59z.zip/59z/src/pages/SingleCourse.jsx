import React, { useEffect, useState } from "react";
import Sidebar from "../component/Sidebar";
import Person from "../component/Person";
import { FileUploader } from "react-drag-drop-files";
import JoditEditor from "jodit-react";
import { Notyf } from "notyf";
import Button from "react-bootstrap/Button";
import Modal from "react-bootstrap/Modal";
import axios from "axios";
import Swal from "sweetalert2";
import { useParams } from "react-router-dom";
function SingleCourse() {
  const { id } = useParams();
  const url = "http://127.0.0.1:8000/api/";
  const url1 = "http://127.0.0.1:8000/images/";
  const [course, setCourse] = useState({});
  const [module, setModule] = useState([]);
  const [schedules, setSchedules] = useState([]);
  useEffect(() => {
    fetch(url + "course/" + id)
      .then((res) => res.json())
      .then((res) => {
        setCourse(res.course);
        var detail = res.course.detail;
        detail = JSON.parse(detail);
        setModule(detail);
        setSchedules(res.duration);
      });
  }, [id]);
  return (
    <>
      <Sidebar />
      <div className="main_content dashboard_part">
        <div className="container-fluid g-0">
          <div className="row">
            <div className="col-lg-12 p-0 ">
              <div className="header_iner d-flex justify-content-between align-items-center">
                <div className="sidebar_icon d-lg-none">
                  <i className="ti-menu" />
                </div>
                <div className="serach_field-area"></div>
                <Person />
              </div>
            </div>
          </div>
          <div className="mt-3  container">
            <h4 className="ms-2">Tên khoá học: {course.name} </h4>
            <h4 className="ms-2">Tóm tắt khoá học: {course.summary}</h4>
            <h4 className="ms-2">Khuyến mãi: {course.discount} %</h4>
            <img
              style={{ width: "400px", height: "auto", marginBottom: "30px" }}
              src={url1 + course.image}
              alt=""
            />
            <div className="row">
              <div className="col-md-6">
                <h4 className="ms-2">Chương trình học</h4>
                {module.length > 0 && (
                  <div
                    className="accordion accordion-flush"
                    id="accordionCourse"
                  >
                    {module.map((item, index) => (
                      <div className="accordion-item">
                        <h2
                          className="accordion-header"
                          id={`flush-heading` + index}
                        >
                          <button
                            className="accordion-button collapsed"
                            type="button"
                            style={{ fontSize: "20px" }}
                            data-bs-toggle="collapse"
                            data-bs-target={`#flush-collapse` + index}
                            aria-expanded="false"
                            aria-controls={`flush-collapse` + index}
                          >
                            {item.name}
                          </button>
                        </h2>
                        <div
                          id={`flush-collapse` + index}
                          className="accordion-collapse collapse"
                          aria-labelledby={`flush-heading` + index}
                          data-bs-parent="#accordionCourse"
                        >
                          <div
                            className="accordion-body"
                            dangerouslySetInnerHTML={{ __html: item.content }}
                          />
                        </div>
                      </div>
                    ))}
                  </div>
                )}
              </div>
              <div className="col-md-6">
                <h4>Giá khoá học</h4>
                {schedules.length > 0 && (
                  <ul className="list-group">
                    {schedules.map((item, index) => (
                      <li className="list-group-item">
                        <span>{item.duration}h </span> ->
                        <span>{item.price} đ</span>
                      </li>
                    ))}
                  </ul>
                )}
              </div>
            </div>
            <div className="row mt-3">
              <div className="col-md-2 ps-3">
                <a href={`/editCourse/` + id} className="btn btn-warning">
                  Chỉnh sửa
                </a>
              </div>
            </div>
          </div>
        </div>
      </div>
    </>
  );
}

export default SingleCourse;
