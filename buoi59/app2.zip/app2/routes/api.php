<?php

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Route;
use App\Http\Controllers\UserController;
use App\Http\Controllers\EducationController;
use App\Http\Controllers\CourseController;
use App\Http\Controllers\ScheduleController;

/*
|--------------------------------------------------------------------------
| API Routes
|--------------------------------------------------------------------------
|
| Here is where you can register API routes for your application. These
| routes are loaded by the RouteServiceProvider and all of them will
| be assigned to the "api" middleware group. Make something great!
|
*/

Route::middleware('auth:sanctum')->get('/user', function (Request $request) {
    return $request->user();
});
Route::post('/checkLogin', [UserController::class,'checkLogin']);
Route::controller(UserController::class)->group(function () {
        Route::get('/getTeacher', 'getTeacher');
});
Route::controller(EducationController::class)->group(function () {
    Route::post('/createEdu', 'store');
    Route::post('/editEdu', 'editEdu');
    Route::post('/deleteEdu', 'deleteEdu');
    Route::post('/switchEdu', 'switchEdu');
    Route::get('/edu', 'index');

});
Route::controller(CourseController::class)->group(function () {
    Route::post('/createCourseCate', 'createCourseCate');
    Route::get('/getCourseCate/{id}', 'index');
    Route::post('/editCourseCate', 'editCourseCate');
    Route::post('/switchCate', 'switchCate');
    Route::post('/DelCate', 'DelCate');
    Route::get('/activeCate','activeCate');
    Route::post('/course', 'createCourse');
    Route::post('/editcourse', 'editcourse'); //Edit không thay đổi file
    Route::post('/editcourse2', 'editcourse2'); //Edit thay đổi file
    Route::get('/courses/{id}','getCourse');
    Route::get('/singleCourse/{id}','singleCourse');
    Route::post('/switchCourse', 'switchCourse');
// ==================================
    Route::post('/createPrice', 'addPrice');
    Route::get('/getCoursePrice/{id}', 'getCoursePrice');
    Route::get('/deleteDuration/{id}', 'deleteDuration');
    Route::get('/getActiveCourses', 'getActiveCourses');
    Route::post('/createPrice', 'addPrice');
// =====================================
    Route::get('/course/{id}', 'singleCourse1');




});
// ===============================================
Route::controller(ScheduleController::class)->group(function () {
    Route::post('/schedule', 'store');
    Route::get('/schedule', 'index');
    Route::get('/deleteSchedule/{id}', 'delete');

});