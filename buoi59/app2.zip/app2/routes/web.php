<?php

use Illuminate\Support\Facades\Route;
use App\Http\Controllers\UserRoleController;
use App\Http\Controllers\UserController;
use App\Http\Controllers\GoogleController;
/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider and all of them will
| be assigned to the "web" middleware group. Make something great!
|
*/

Route::middleware('checkLogin')->controller(UserRoleController::class)->group(function () {

    Route::get('/roles', 'index');
    Route::post('/roles', 'create');
    Route::post('/updateRole', 'update');
    Route::post('/switchRole', 'switchRole');
    Route::post('/deleteRole', 'destroy');
});
    Route::get('/',[UserController::class,'login']);
    Route::post('/checkLogin',[UserController::class,'checkLoginAdmin']);

Route::middleware('checkLogin')->controller(UserController::class)->group(function () {
    Route::get('/users', 'index');
    Route::post('/user', 'create');
    Route::post('/updateUSRole', 'updateUSRole');
    Route::post('/updateUSstatus', 'updateUSstatus');
    Route::post('/updateUSname', 'updateUSname');
    Route::post('/updateUSemail', 'updateUSemail');
    Route::get('/logout', 'logout');
});
Route::controller(GoogleController::class)->group(function(){
    Route::get('auth/google', 'redirectToGoogle')->name('auth.google');
    Route::get('auth/google/callback', 'handleGoogleCallback');
});
