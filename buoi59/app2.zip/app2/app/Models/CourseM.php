<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class CourseM extends Model
{
    protected $table='courses';
    protected $fillable=['id','name','summary','image','discount','idCourseCate','Grade','status','detail','created_at','updated_at'];
    use HasFactory;
}
