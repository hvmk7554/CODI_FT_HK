<?php

namespace App\Http\Controllers;

use App\Models\scheduleM;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Validator;
class ScheduleController extends Controller
{
    protected function getSchedule(){
        $schedule = DB::table('class_schedule')
        ->join('users','class_schedule.idTeacher','=','users.id')
        ->join('courses','class_schedule.idcourse','=','courses.id')
        ->select('courses.name as coursename','users.name as teacher','class_schedule.id as id','class_schedule.schedule as schedule')->get();
        return $schedule;
    }
    /**
     * Display a listing of the resource.
     */
    public function index()
    {
        $result = $this->getSchedule();
        return response()->json($result);
    }

    /**
     * Show the form for creating a new resource.
     */
    public function delete($id)
    {
        $check = scheduleM::where('id',$id)->count('id');
        if($check==0){
            return response()->json(['check'=>false,'msg'=>'Không tồn tại mã lịch']);
        }
        scheduleM::where('id',$id)->delete();
         $result = $this->getSchedule();
         return response()->json(['check'=>true,'result'=>$result]);
    }

    /**
     * Store a newly created resource in storage.
     */
    public function store(Request $request)
    {
        $validator = Validator::make(
            $request->all(),
            [
                'idTeacher' => 'required|exists:users,id',
                'idcourse' => 'required|exists:courses,id',
                'schedule' => 'required',

            ],
            [
                'idTeacher.required' => 'Thiếu mã giáo viên',
                'idTeacher.exists' => 'Mã giáo viên không tồn tại',
                'idcourse.required' => 'Chưa có mã khoá học',
                'idcourse.exists' => 'Mã khoá học không hợp lệ',
                'schedule.required'=>'Chưa nhận được lịch dạy'
            ],
        );
        if ($validator->fails()) {
            return response()->json(['check' => false, 'msg' => $validator->errors()]);
        }
        scheduleM::create(['idTeacher'=>$request->idTeacher,'idcourse'=>$request->idcourse,'schedule'=>$request->schedule]);
        $result = $this->getSchedule();
        return response()->json(['check'=>true,'result'=>$result]);
    }

    /**
     * Display the specified resource.
     */
    public function show(scheduleM $scheduleM)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     */
    public function edit(scheduleM $scheduleM)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     */
    public function update(Request $request, scheduleM $scheduleM)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     */
    public function destroy(scheduleM $scheduleM)
    {
        //
    }
}
