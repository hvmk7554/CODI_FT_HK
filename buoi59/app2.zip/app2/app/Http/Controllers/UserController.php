<?php

namespace App\Http\Controllers;
use App\Models\UserRoleM;
use App\Models\User;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Facades\Mail;
use App\Mail\UserMail;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Validator;
use Illuminate\Support\Facades\Auth;

class UserController extends Controller
{
    /**
     * Display a listing of the resource.
     */
    public function index()
    {
        $roles = UserRoleM::where('status', 1)
            ->select('id', 'name')
            ->get();
        // $users = DB::table('users')
        //         ->join('role_tbl','users.idRole','=','role_tbl.id')
        //         ->select('users.name','role_tbl.name as rolename')
        //         ->get();

        $users = User::join('role_tbl', 'users.idRole', '=', 'role_tbl.id')
            ->select('users.*', 'role_tbl.name as rolename')
            ->get();
        return view('users.users', compact('roles', 'users'));
    }

    /**
     * Show the form for creating a new resource.
     */
    public function create(Request $request)
    {
        $validator = Validator::make(
            $request->all(),
            [
                'name' => 'required',
                'email' => 'required|email|unique:users,email',
                'idRole' => 'required|exists:role_tbl,id',
            ],
            [
                'name.required' => 'Thiếu tên tài khoản',
                'email.required' => 'Thiếu email tài khoản',
                'email.email' => 'Email tài khoản không hợp lệ',
                'email.unique' => 'Email tài khoản bị trùng',
                'idRole.required' => 'Mã loại tài khoản không hợp lệ',
                'idRole.exists' => 'Mã loại tài khoản không tồn tại',
            ],
        );
        if ($validator->fails()) {
            return response()->json(['check' => false, 'msg' => $validator->errors()]);
        }
        $password = random_int(10000, 99999);
        $hash = Hash::make($password);
        User::create(['name' => $request->name, 'email' => $request->email, 'idRole' => $request->idRole, 'password' => Hash::make($password)]);
        $mailData = [
            'name' => $request->name,
            'email' => $request->email,
            'password' => $password,
        ];
        Mail::to($request->email)->send(new UserMail($mailData));
        return response()->json(['check' => true]);
    }
    // ====================================
    public function updateUSname(Request $request)
    {
        $validator = Validator::make(
            $request->all(),
            [
                'id' => 'required|exists:users,id',
                'name' => 'required',
            ],
            [
                'id.required' => 'Thiếu mã tài khoản',
                'id.exists' => 'Mã tài khoản không tồn tại',
                'name.required' => 'Thiếu tên tài khoản',
            ],
        );
        if ($validator->fails()) {
            return response()->json(['check' => false, 'msg' => $validator->errors()]);
        }
        User::where('id', $request->id)->update(['name' => $request->name, 'updated_at' => now()]);
        return response()->json(['check' => true]);
    }
    // ====================================
    public function updateUSemail(Request $request)
    {
        $validator = Validator::make(
            $request->all(),
            [
                'id' => 'required|exists:users,id',
                'email' => 'required|email|unique:users,email',
            ],
            [
                'id.required' => 'Thiếu mã tài khoản',
                'id.exists' => 'Mã tài khoản không tồn tại',
                'email.required' => 'Thiếu email tài khoản',
                'email.email' => 'Email tài khoản không đúng định dạng',
                'email.unique' => 'Email bị trùng',
            ],
        );
        if ($validator->fails()) {
            return response()->json(['check' => false, 'msg' => $validator->errors()]);
        }
        User::where('id', $request->id)->update(['email' => $request->email, 'updated_at' => now()]);
        $username = User::where('id', $request->id)->value('name');
        $mailData = [
            'name' => $username,
            'email' => $request->email,
        ];
        Mail::to($request->email)->send(new UserMail($mailData));
        return response()->json(['check' => true]);
    }
    // ====================================
    public function updateUSstatus(Request $request)
    {
        $validator = Validator::make(
            $request->all(),
            [
                'id' => 'required|exists:users,id',
                'status' => 'required|numeric|min:0|max:1',
            ],
            [
                'id.required' => 'Thiếu mã tài khoản',
                'id.exists' => 'Mã tài khoản không tồn tại',
                'status.required' => ' Thiếu mã trạng thái',
                'status.numeric' => 'Mã trạng thái không hợp lệ',
                'status.min' => 'Mã trạng thái không hợp lệ',
                'status.max' => 'Mã trạng thái không hợp lệ',
            ],
        );
        if ($validator->fails()) {
            return response()->json(['check' => false, 'msg' => $validator->errors()]);
        }
        User::where('id', $request->id)->update(['status' => $request->status, 'updated_at' => now()]);
        return response()->json(['check' => true]);
    }
    // ====================================

    public function updateUSRole(Request $request)
    {
        $validator = Validator::make(
            $request->all(),
            [
                'id' => 'required|exists:users,id',
                'role' => 'required|exists:role_tbl,id',
            ],
            [
                'id.required' => 'Thiếu mã tài khoản',
                'id.exists' => 'Mã tài khoản không tồn tại',
                'role.required' => 'Mã loại tài khoản không hợp lệ',
                'role.exists' => 'Mã loại tài khoản không tồn tại',
            ],
        );
        if ($validator->fails()) {
            return response()->json(['check' => false, 'msg' => $validator->errors()]);
        }
        User::where('id', $request->id)->update(['idRole' => $request->role, 'updated_at' => now()]);
        return response()->json(['check' => true]);
    }

    public function checkLogin(Request $request)
    {
        $Validator = Validator::make($request->all(), [
            'email'=>'required|email|exists:users,email',
            'password'=>'required',

        ],[
            'email.required'=>'Chưa nhận được email tài khoản',
            'email.email'=>'Email tài khoản không hợp lệ',
            'idRole.required'=>'Chưa nhận được loại tài khoản',
            'idRole.exists'=>'Loại tài khoản không tồn tại',

        ]);
        if ($Validator->fails()) {
            return response()->json(['check' => false, 'msg' => $Validator->errors()]);
        }
         if(Auth::attempt(['email' => $request->email,'status'=>1, 'password' => $request->password],true)){
          $token=Auth::user()->remember_token;
          return response()->json(['check'=>true,'token'=>$token]);
        }else{
            return response()->json(['check'=>false,'msg'=>'Sai tên đăng nhập hoặc mật khẩu']);
        }
    }
    /**
     * Store a newly created resource in storage.
     */
    public function login(Request $request)
    {
        return view('users.login');
    }

    /**
     * Display the specified resource.
     */
    public function checkLoginAdmin(Request $request,User $user)
    {
        $Validator = Validator::make($request->all(), [
            'email'=>'required|email|exists:users,email',
            'password'=>'required',

        ],[
            'email.required'=>'Chưa nhận được email tài khoản',
            'idRole.required'=>'Chưa nhận được loại tài khoản',
            'idRole.exists'=>'Loại tài khoản không tồn tại',
            'email.email'=>'Email tài khoản không hợp lệ',
        ]);
        if ($Validator->fails()) {
            return response()->json(['check' => false, 'msg' => $Validator->errors()]);
        }
         if(Auth::attempt(['email' => $request->email,'status'=>1, 'password' => $request->password],true)){
            $check = DB::Table('users')->join('role_tbl','users.idRole','=','role_tbl.id')
            ->where('role_tbl.name','admin')->where('users.id',Auth::id())->count('users.id');
            if($check==0){
            return response()->json(['check'=>false,'msg'=>'Vui lòng đăng nhập bằng tài khoản admin']);
            }else{
                return  response()->json(['check'=>true]);
            }
        }else{
            return response()->json(['check'=>false,'msg'=>'Sai tên đăng nhập hoặc mật khẩu']);
        }
    }

    /**
     * Show the form for editing the specified resource.
     */
    public function logout(Request $request,User $user)
    {
        if (Auth::check()) {
            Auth::logout();
            $request->session()->invalidate();
            $request->session()->regenerateToken();
        }
                    return redirect('/');
    }
    //==================================
    public function getTeacher(){
        $result= DB::Table('users')
        ->join('role_tbl','users.idRole','=','role_tbl.id')
        ->where('role_tbl.name','=','teacher')
        ->select('users.id as id','users.name as name')->get();
        return response()->json($result);
    }
    /**
     * Update the specified resource in storage.
     */
    public function update(Request $request, User $user)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     */
    public function destroy(User $user)
    {
        //
    }
}
