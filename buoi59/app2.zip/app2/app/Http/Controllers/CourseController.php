<?php

namespace App\Http\Controllers;

use App\Models\CourseCateM;
use App\Models\durationM;
use App\Models\CourseM;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Validator;
use Illuminate\Support\Facades\File;
class CourseController extends Controller
{

    public function getCourseCate ($id){
        $result=DB::Table('course_cates')->where('idEdu',$id)->get();
        return $result;
    }
    public function getDuration ($id){
        $result= DB::Table('course_duration')->where('idCourse',$id)->select('id','duration','price')->get();
        return $result;
    }
    //===================================================
    public function getActiveCourses(){
        $result = DB::table('courses')->where('status',1)->select('id','name')->get();
        return response()->json($result);
    }
    //====================================================
    public function getCoursePrice($id){
        $result =$this->getDuration($id);
        return response()->json($result);
    }
    // ====================================================
    public function addPrice (Request $request){
         $validator =  Validator::make(
            $request->all(),
            [
                'duration' => 'required|min:0',
                'id'=>'required|exists:courses,id',
                'price'=>'required|min:0'
            ],
            [
                'duration.required' => 'Thiếu thời lượng khoá học',
                'duration.min' => 'Thời lượng khoá học không hợp lệ',
                'price.required'=>'Thiếu giá khoá học',
                'price.min'=>'Giá khoá học không hợp lệ',
                'id.required'=>'Thiếu mã khoá học',
                'id.exists'=>'Mã khoá học không tồn tại',
            ],
        );
        if ($validator->fails()) {
            return response()->json(['check' => false, 'msg' => $validator->errors()]);
        }
        durationM::create(['idCourse'=>$request->id,'duration'=>$request->duration,'price'=>$request->price]);
        $result = $this->getDuration($request->id);
        return response()->json(['check'=>true, 'result'=>$result]);
    }
    //-====================================================
    public function deleteDuration($id){
        $check = durationM::where('id',$id)->count('id');
        if($check==0){
            return response()->json(['check'=>false,'msg'=>'Không tồn tại giá trị']);
        }
        $idCourse=durationM::where('id',$id)->value('idCourse');
        durationM::where('id',$id)->delete();
        $result =$this->getDuration($idCourse);
        return response()->json(['check'=>true,'result'=>$result]);
    }
    // ====================================================

    public function switchCate(Request $request){
        $validator =  Validator::make(
            $request->all(),
            [
                'status' => 'required|min:0|max:1',
                'id'=>'required|numeric|exists:course_cates,id',
            ],
            [
                'status.required' => 'Thiếu mã trạng thái loại hình lớp học',
                'status.min|status.max'=>'Mã trạng thái không hợp lệ',
                'id.required'=>'Thiếu mã loại hình lớp học',
                'id.exists'=>'Mã loại hình lớp học không tồn tại',
            ],
        );
        if ($validator->fails()) {
            return response()->json(['check' => false, 'msg' => $validator->errors()]);
        }
        CourseCateM::where('id',$request->id)->update(['status'=>$request->status,'updated_at'=>now()]);
        $idEdu = CourseCateM::where('id',$request->id)->value('idEdu');
        $result = $this->getCourseCate($idEdu);
        return  response()->json(['check'=>true,'result'=>$result]);
    }
    // ===================
    public function activeCate(){
        $result = CourseCateM::where('status',1)->select('id','name')->get();
        return response()->json($result);
    }
     // ==================
    public function editCourseCate(Request $request){
        $validator =  Validator::make(
            $request->all(),
            [
                'name' => 'required',
                'id'=>'required|numeric|exists:course_cates,id',
            ],
            [
                'name.required' => 'Thiếu tên loại hình lớp học',
                'id.required'=>'Thiếu mã loại hình lớp học',
                'id.exists'=>'Mã loại hình lớp học không tồn tại',
            ],
        );
        if ($validator->fails()) {
            return response()->json(['check' => false, 'msg' => $validator->errors()]);
        }
        CourseCateM::where('id',$request->id)->update(['name'=>$request->name,'updated_at'=>now()]);
        $idEdu = CourseCateM::where('id',$request->id)->value('idEdu');
        $result = $this->getCourseCate($idEdu);
        return  response()->json(['check'=>true,'result'=>$result]);
    }
     // ==================
    public function DelCate(Request $request){
        $validator =  Validator::make(
            $request->all(),
            [
                'idD'=>'required|exists:course_cates,id',
            ],
            [
                'idD.required'=>'Thiếu mã loại hình lớp học',
                'idD.exists'=>'Mã loại hình lớp học không tồn tại',
            ],
        );
        if ($validator->fails()) {
            return response()->json(['check' => false, 'msg' => $validator->errors()]);
        }
        $idEdu = CourseCateM::where('id',$request->idD)->value('idEdu');
        $check= CourseM::where('idCourseCate',$request->idD)->count('id');
        if($check!=0){
            return response()->json(['check'=>false,'msg'=>'Có khoá học trong loại này']);
        }
        $idEdu = CourseCateM::where('id',$request->idD)->value('idEdu');
        CourseCateM::where('id',$request->idD)->delete();
        $result =  DB::Table('course_cates')->where('idEdu',$idEdu)->get();

        return  response()->json(['check'=>true,'result'=>$result]);
    }
    // ==================
    public function createCourseCate(Request $request){
        $validator =  Validator::make(
            $request->all(),
            [
                'name' => 'required',
                'idEdu'=>'required|exists:edu_tbl,id',
            ],
            [
                'name.required' => 'Thiếu tên loại hình lớp học',
                'idEdu.required'=>'Thiếu mã loại hình giáo dục',
                'idEdu.exists'=>'Mã loại hình giáo dục không tồn tại',
            ],
        );
        if ($validator->fails()) {
            return response()->json(['check' => false, 'msg' => $validator->errors()]);
        }
        CourseCateM::create(['name'=>$request->name,'idEdu'=>$request->idEdu]);
        $result = $this->getCourseCate($request->idEdu);
        return  response()->json(['check'=>true,'result'=>$result]);
    }
    /**
     * Display a listing of the resource.
     */
    public function index($id)
    {
        $result = $this->getCourseCate($id);
        return response()->json($result);
    }
    public function getCourse($id){
        $result = DB::Table('courses')->where('idCourseCate',$id)->get();
        return $result;
    }
    public function getAdminCourses (){
        $result= $this->getCourse();
        return response()->json($result);
    }
    /**
     * Show the form for creating a new resource.
     */
    public function createCourse(Request $request)
    {
        $validator =  Validator::make(
            $request->all(),
            [
                'coursename' => 'required|unique:courses,name',
                'summary'=>'required',
                'grade'=>'required',
                'idCate'=>'required|exists:course_cates,id',
                'file'=>'required|mimes:gif,jpeg,png,webp,jpg,JPG,jfif,GIF,JPEG,PNG,WEBP',
                'module'=>'required'
            ],
            [
                'coursename.required' => 'Thiếu tên khoá học',
                'coursename.unique' => 'Tên khoá học bị trùng',
                'summary.required' => 'Thiếu tóm tắt nội dung khoá học',
                'grade.required' => 'Thiếu khối lớp của khoá học',
                'idCate.required' => 'Thiếu mã loại hình lớp',
                'idCate.exists' => 'Mã loại hình lớp không tồn tại',
                'file.required' => 'Thiếu hình ảnh khoá học',
                'file.mimes' => 'Hình ảnh khoá học không đúng định dạng',
                'module.required'=>'Thiếu module khoá học',
            ],
        );
        if ($validator->fails()) {
            return response()->json(['check' => false, 'msg' => $validator->errors()]);
        }
        $filename=$_FILES['file']['name'];
        $file_tmp=$_FILES['file']['tmp_name'];
        move_uploaded_file($file_tmp,'images/'.$filename);
        CourseM::create(['name'=>$request->coursename,'summary'=>$request->summary,'image'=>$filename,
        'discount'=>$request->discount,'idCourseCate'=>$request->idCate,'Grade'=>$request->grade,'detail'=>$request->module]);
        $result = $this->getCourse($request->idCate);
        return  response()->json(['check'=>true,'result'=>$result]);
    }

    //==============================================


    public function switchCourse (Request $request){
        $validator =  Validator::make(
            $request->all(),
            [
                'id'=>'required|exists:courses,id',
                'status'=>'required|numeric|min:0|max:1',
            ],
            [
                'id.required'=>'Thiếu mã khoá học',
                'id.exists'=>'Mã khoá học không tồn tại',
                'status.required'=>'Thiếu trạng thái khoá học',
                'status.numeric'=>'Trạng thái khoá học không hợp lệ',
                'status.max'=>'Trạng thái khoá học không hợp lệ',
                'status.max'=>'Trạng thái khoá học không hợp lệ',
            ],
        );
        if ($validator->fails()) {
            return response()->json(['check' => false, 'msg' => $validator->errors()]);
        }
        CourseM::where('id',$request->id)->update(['status'=>$request->status,'updated_at'=>now()]);
        $idCate=  CourseM::where('id',$request->id)->value('idCourseCate');
        $result = $this->getCourse($idCate);
        return  response()->json(['check'=>true,'result'=>$result]);
    }
     /**
     * Show the form for creating a new resource.
     */
    public function editcourse(Request $request)
    {
        $validator =  Validator::make(
            $request->all(),
            [
                'id'=>'required|exists:courses,id',
                'coursename' => 'required',
                'summary'=>'required',
                'grade'=>'required',
                'idCate'=>'required|exists:course_cates,id',
                'module'=>'required',
            ],
            [
                'id.required'=>'Thiếu mã khoá học',
                'id.exists'=>'Mã khoá học không tồn tại',
                'coursename.required' => 'Thiếu tên khoá học',
                'coursename.unique' => 'Tên khoá học bị trùng',
                'summary.required' => 'Thiếu tóm tắt nội dung khoá học',
                'grade.required' => 'Thiếu khối lớp của khoá học',
                'idCate.required' => 'Thiếu mã loại hình lớp',
                'idCate.exists' => 'Mã loại hình lớp không tồn tại',
                'module.required'=>'Thiếu module khoá học',
            ],
        );
        if ($validator->fails()) {
            return response()->json(['check' => false, 'msg' => $validator->errors()]);
        }
        CourseM::where('id',$request->id)->update(['name'=>$request->coursename,'summary'=>$request->summary,
        'discount'=>$request->discount,'idCourseCate'=>$request->idCate,'Grade'=>$request->grade,'detail'=>$request->module]);
        $idCate=  CourseM::where('id',$request->id)->value('idCourseCate');
        $result = $this->getCourse($idCate);
        return  response()->json(['check'=>true,'result'=>$result]);
    }
    
    //===========================================
     public function editcourse2(Request $request)
    {
        $validator =  Validator::make(
            $request->all(),
            [
                'id'=>'required|exists:courses,id',
                'coursename' => 'required',
                'summary'=>'required',
                'grade'=>'required',
                'idCate'=>'required|exists:course_cates,id',
                'module'=>'required',
                'file'=>'required|mimes:gif,jpeg,png,webp,jpg,JPG,jfif,GIF,JPEG,PNG,WEBP',
            ],
            [
                'id.required'=>'Thiếu mã khoá học',
                'id.exists'=>'Mã khoá học không tồn tại',
                'coursename.required' => 'Thiếu tên khoá học',
                'coursename.unique' => 'Tên khoá học bị trùng',
                'summary.required' => 'Thiếu tóm tắt nội dung khoá học',
                'grade.required' => 'Thiếu khối lớp của khoá học',
                'idCate.required' => 'Thiếu mã loại hình lớp',
                'idCate.exists' => 'Mã loại hình lớp không tồn tại',
                'file.required' => 'Thiếu hình ảnh khoá học',
                'module.required'=>'Thiếu module khoá học',
                'file.required' => 'Thiếu hình ảnh khoá học',
                'file.mimes' => 'Hình ảnh khoá học không hợp lệ',

            ],
        );
        if ($validator->fails()) {
            return response()->json(['check' => false, 'msg' => $validator->errors()]);
        }
        $filenameold=CourseM::where('id',$request->id)->value('image');
        $check = CourseM::where('image',$filenameold)->where('id','!=',$request->id)->count('id');
        $filename=$_FILES['file']['name'];
        $file_tmp=$_FILES['file']['tmp_name'];
        if($check==0){
            File::delete(public_path("images/".$filenameold));
        }else{
            $temp = explode(".", $_FILES['file']['name']);
            $filename = $_FILES['file']['name'].random_int(1,9). '.' . end($temp);
        }
        move_uploaded_file($file_tmp,'images/'.$filename);
        CourseM::where('id',$request->id)->update(['name'=>$request->coursename,'summary'=>$request->summary,'image'=>$filename,
        'discount'=>$request->discount,'idCourseCate'=>$request->idCate,'Grade'=>$request->grade,'detail'=>$request->module]);
        $result = $this->getCourse($request->idCate);
        return  response()->json(['check'=>true,'result'=>$result]);
    }
    //===========================================
    public function singleCourse($id){
        $result = CourseM::where('id',$id)->first();
        return response()->json($result);
    }
    /**
     * Store a newly created resource in storage.
     */
    public function singleCourse1($id)
    {
        $result = CourseM::where('id',$id)->first();
        $duration =durationM::where('idCourse',$id)->get();
        return response()->json(['course'=>$result,'duration'=>$duration]);
    }

    /**
     * Display the specified resource.
     */
    public function show(CourseCateM $courseCateM)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     */
    public function edit(CourseCateM $courseCateM)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     */
    public function update(Request $request, CourseCateM $courseCateM)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     */
    public function destroy(CourseCateM $courseCateM)
    {
        //
    }
}
